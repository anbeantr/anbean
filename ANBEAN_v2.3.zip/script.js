document.getElementById('search').addEventListener('keydown',e=>{
if(e.key==='Enter'){
alert('Arama altyapısı hazır. Sonraki sürümde gerçek sonuçlar eklenecek.');
}
});
